package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {

    // Player State
    @Query("SELECT * FROM player_state WHERE id = 1")
    fun getPlayerState(): Flow<PlayerStateEntity?>

    @Query("SELECT * FROM player_state WHERE id = 1")
    suspend fun getPlayerStateSync(): PlayerStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayerState(state: PlayerStateEntity)

    // Dogs
    @Query("SELECT * FROM dogs ORDER BY rarity DESC, level DESC")
    fun getAllDogs(): Flow<List<DogEntity>>

    @Query("SELECT * FROM dogs WHERE isUnlocked = 1 ORDER BY level DESC")
    fun getUnlockedDogs(): Flow<List<DogEntity>>

    @Query("SELECT * FROM dogs WHERE isUnlocked = 1 AND isInWarehouse = 1 ORDER BY level DESC")
    fun getWarehouseDogs(): Flow<List<DogEntity>>

    @Query("SELECT * FROM dogs WHERE isUnlocked = 1 AND isInWarehouse = 0 ORDER BY level DESC")
    fun getActiveDogs(): Flow<List<DogEntity>>

    @Query("SELECT * FROM dogs WHERE id = :id")
    suspend fun getDogById(id: String): DogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDogs(dogs: List<DogEntity>)

    @Update
    suspend fun updateDog(dog: DogEntity)

    // Missions
    @Query("SELECT * FROM missions ORDER BY isClaimed ASC, rewardCoins DESC")
    fun getAllMissions(): Flow<List<MissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMissions(missions: List<MissionEntity>)

    @Update
    suspend fun updateMission(mission: MissionEntity)

    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insertTransaction(transaction: TransactionEntity)

    // Withdrawals
    @Query("SELECT * FROM withdrawals ORDER BY timestamp DESC")
    fun getAllWithdrawals(): Flow<List<WithdrawalEntity>>

    @Insert
    suspend fun insertWithdrawal(withdrawal: WithdrawalEntity)

    // Messages
    @Query("SELECT * FROM messages ORDER BY isRead ASC, id DESC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE isRead = 0")
    fun getUnreadMessageCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Query("UPDATE messages SET isRead = 1 WHERE id = :id")
    suspend fun markMessageRead(id: String)

    @Query("UPDATE messages SET isRead = 1")
    suspend fun markAllMessagesRead()
}
