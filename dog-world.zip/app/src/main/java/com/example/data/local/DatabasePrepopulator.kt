package com.example.data.local

object DatabasePrepopulator {

    suspend fun populateInitialData(dao: GameDao) {
        // 1. Initial Player State
        val initialState = PlayerStateEntity(
            id = 1,
            level = 8,
            exp = 420,
            maxExp = 1000,
            coins = 18450.0,
            totalEarnedCoins = 64200.0,
            dailyStreak = 4,
            lastClaimTimestamp = System.currentTimeMillis() - 86400000L,
            userName = "PawsomeTrainer",
            userId = "#DW-94821",
            avatarDrawable = "img_dog_corgi_1786462778833",
            soundEnabled = true,
            notificationsEnabled = true
        )
        dao.savePlayerState(initialState)

        // 2. Initial Dogs Catalog
        val initialDogs = listOf(
            DogEntity(
                id = "corgi_king",
                name = "Royal Corgi",
                breed = "Welsh Corgi",
                level = 12,
                rarity = DogRarity.LEGENDARY,
                baseEarningsPerSec = 15.0,
                drawableName = "img_dog_corgi_1786462778833",
                description = "Crown-wearing royal Corgi who rules the Dog World kingdom.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = true,
                upgradeCost = 1200.0,
                count = 1
            ),
            DogEntity(
                id = "ninja_shiba",
                name = "Ninja Shiba",
                breed = "Shiba Inu",
                level = 10,
                rarity = DogRarity.EPIC,
                baseEarningsPerSec = 10.0,
                drawableName = "img_dog_shiba_1786462789627",
                description = "Agile ninja Shiba inu skilled in stealth barks and quick merges.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 850.0,
                count = 1
            ),
            DogEntity(
                id = "star_poodle",
                name = "Star Poodle",
                breed = "Standard Poodle",
                level = 8,
                rarity = DogRarity.RARE,
                baseEarningsPerSec = 6.5,
                drawableName = "img_dog_poodle_1786462802708",
                description = "Stylish fashion poodle with star sunglasses and endless charm.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 500.0,
                count = 1
            ),
            DogEntity(
                id = "golden_captain",
                name = "Captain Golden",
                breed = "Golden Retriever",
                level = 15,
                rarity = DogRarity.LEGENDARY,
                baseEarningsPerSec = 22.0,
                drawableName = "img_app_icon_1786462753456",
                description = "Brave leader of the dog rescue fleet with a heart of pure gold.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 2500.0,
                count = 1
            ),
            DogEntity(
                id = "bulldog_boss",
                name = "Bulldog Boss",
                breed = "English Bulldog",
                level = 5,
                rarity = DogRarity.RARE,
                baseEarningsPerSec = 4.2,
                drawableName = "img_dog_corgi_1786462778833",
                description = "Tough on the outside, gentle on the inside. Protects the coin vault.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 300.0,
                count = 1
            ),
            DogEntity(
                id = "samoyed_sparkle",
                name = "Sparkle Samoyed",
                breed = "Samoyed",
                level = 18,
                rarity = DogRarity.SPECIAL,
                baseEarningsPerSec = 35.0,
                drawableName = "img_dog_poodle_1786462802708",
                description = "Fluffy cloud dog whose smile brings instant coin multipliers!",
                isUnlocked = true,
                isInWarehouse = true,
                isSelectedActive = false,
                upgradeCost = 4000.0,
                count = 1
            ),
            DogEntity(
                id = "husky_glacier",
                name = "Glacier Husky",
                breed = "Siberian Husky",
                level = 7,
                rarity = DogRarity.EPIC,
                baseEarningsPerSec = 8.0,
                drawableName = "img_dog_shiba_1786462789627",
                description = "Vocal arctic howling champion who loves cold treats.",
                isUnlocked = true,
                isInWarehouse = true,
                isSelectedActive = false,
                upgradeCost = 650.0,
                count = 1
            ),
            DogEntity(
                id = "pug_royalty",
                name = "Lord Pug",
                breed = "Pug",
                level = 3,
                rarity = DogRarity.COMMON,
                baseEarningsPerSec = 1.8,
                drawableName = "img_dog_corgi_1786462778833",
                description = "Charming wrinkled noble who enjoys snuggles and nap coins.",
                isUnlocked = true,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 150.0,
                count = 1
            ),
            DogEntity(
                id = "dachshund_flash",
                name = "Flash Dachshund",
                breed = "Dachshund",
                level = 2,
                rarity = DogRarity.COMMON,
                baseEarningsPerSec = 1.2,
                drawableName = "img_dog_shiba_1786462789627",
                description = "Long body, fast legs! Speedster of the canine racing ring.",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 100.0,
                count = 0
            ),
            DogEntity(
                id = "labrador_hero",
                name = "Hero Lab",
                breed = "Labrador Retriever",
                level = 6,
                rarity = DogRarity.RARE,
                baseEarningsPerSec = 5.0,
                drawableName = "img_app_icon_1786462753456",
                description = "Loyal companion and swimming champ.",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 450.0,
                count = 0
            ),
            DogEntity(
                id = "chihuahua_thunder",
                name = "Thunder Chihuahua",
                breed = "Chihuahua",
                level = 1,
                rarity = DogRarity.COMMON,
                baseEarningsPerSec = 0.8,
                drawableName = "img_dog_poodle_1786462802708",
                description = "Tiny body, gigantic thunder bark power!",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 80.0,
                count = 0
            ),
            DogEntity(
                id = "samurai_akita",
                name = "Samurai Akita",
                breed = "Akita Inu",
                level = 14,
                rarity = DogRarity.LEGENDARY,
                baseEarningsPerSec = 20.0,
                drawableName = "img_dog_shiba_1786462789627",
                description = "Honorbound guardian of the ancient merge shrine.",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 2000.0,
                count = 0
            ),
            DogEntity(
                id = "dalmatian_officer",
                name = "Officer Spot",
                breed = "Dalmatian",
                level = 9,
                rarity = DogRarity.EPIC,
                baseEarningsPerSec = 9.5,
                drawableName = "img_dog_corgi_1786462778833",
                description = "Spotted hero on duty ensuring fair play and rewards.",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 750.0,
                count = 0
            ),
            DogEntity(
                id = "rainbow_mutt",
                name = "Rainbow Phoenix Mutt",
                breed = "Mythic Mutt",
                level = 20,
                rarity = DogRarity.SPECIAL,
                baseEarningsPerSec = 50.0,
                drawableName = "img_app_icon_1786462753456",
                description = "Ultimate mythical dog synthesized from ancient cosmic powers!",
                isUnlocked = false,
                isInWarehouse = false,
                isSelectedActive = false,
                upgradeCost = 10000.0,
                count = 0
            )
        )
        dao.insertDogs(initialDogs)

        // 3. Initial Missions
        val missions = listOf(
            MissionEntity(
                id = "m1",
                title = "Daily Bark & Play",
                description = "Interact with your center dog 5 times",
                targetCount = 5,
                currentCount = 3,
                rewardCoins = 1000.0,
                isClaimed = false,
                isDaily = true
            ),
            MissionEntity(
                id = "m2",
                title = "Random Merge Spin",
                description = "Spin the Random Merge wheel 3 times",
                targetCount = 3,
                currentCount = 1,
                rewardCoins = 2500.0,
                isClaimed = false,
                isDaily = true
            ),
            MissionEntity(
                id = "m3",
                title = "Canine Upgrade",
                description = "Upgrade any dog level 2 times",
                targetCount = 2,
                currentCount = 2,
                rewardCoins = 3000.0,
                isClaimed = false,
                isDaily = true
            ),
            MissionEntity(
                id = "m4",
                title = "Master Collector",
                description = "Unlock at least 8 unique dog breeds",
                targetCount = 8,
                currentCount = 7,
                rewardCoins = 10000.0,
                isClaimed = false,
                isDaily = false
            )
        )
        dao.insertMissions(missions)

        // 4. Initial Messages
        val messages = listOf(
            MessageEntity(
                id = "msg_1",
                title = "Welcome to Dog World v2.0!",
                body = "Welcome Trainer! Explore our colorful dog kingdom, perform Random Merge spins, collect rare breeds, and earn daily rewards!",
                date = "Today, 09:00 AM",
                isRead = false,
                category = "NEWS"
            ),
            MessageEntity(
                id = "msg_2",
                title = "Daily Login Bonus Credited",
                body = "Your Day 4 streak bonus of +2,500 Coins has been safely credited to your wallet balance.",
                date = "Today, 08:30 AM",
                isRead = false,
                category = "REWARD"
            ),
            MessageEntity(
                id = "msg_3",
                title = "Security & Prototype Notice",
                body = "Dog World uses local persistence for prototype rewards. All withdrawal requests are simulated for compliance testing.",
                date = "Yesterday",
                isRead = true,
                category = "SYSTEM"
            )
        )
        dao.insertMessages(messages)

        // 5. Initial Transactions
        val transactions = listOf(
            TransactionEntity(
                title = "Daily Streak Day 4 Bonus",
                amount = 2500.0,
                type = "EARN",
                timestamp = System.currentTimeMillis() - 3600000L
            ),
            TransactionEntity(
                title = "Random Merge Wheel Win (Ninja Shiba)",
                amount = 1500.0,
                type = "EARN",
                timestamp = System.currentTimeMillis() - 7200000L
            ),
            TransactionEntity(
                title = "Upgraded Royal Corgi to Lv. 12",
                amount = -1200.0,
                type = "SPEND",
                timestamp = System.currentTimeMillis() - 14400000L
            )
        )
        for (tx in transactions) {
            dao.insertTransaction(tx)
        }

        // 6. Initial Withdrawal Requests
        val withdrawals = listOf(
            WithdrawalEntity(
                amount = 25000.0,
                usdValue = 25.0,
                method = "PayPal",
                accountInfo = "trainer***@gmail.com",
                status = "APPROVED",
                timestamp = System.currentTimeMillis() - 172800000L
            ),
            WithdrawalEntity(
                amount = 10000.0,
                usdValue = 10.0,
                method = "GCash",
                accountInfo = "+63 917 *** 8821",
                status = "COMPLETED",
                timestamp = System.currentTimeMillis() - 432000000L
            )
        )
        for (w in withdrawals) {
            dao.insertWithdrawal(w)
        }
    }
}
