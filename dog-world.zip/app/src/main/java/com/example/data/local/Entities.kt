package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class DogRarity {
    COMMON,
    RARE,
    EPIC,
    LEGENDARY,
    SPECIAL
}

@Entity(tableName = "dogs")
data class DogEntity(
    @PrimaryKey val id: String,
    val name: String,
    val breed: String,
    val level: Int,
    val rarity: DogRarity,
    val baseEarningsPerSec: Double,
    val drawableName: String, // e.g. "img_dog_corgi_1786462778833"
    val description: String,
    val isUnlocked: Boolean = false,
    val isInWarehouse: Boolean = false,
    val isSelectedActive: Boolean = false,
    val upgradeCost: Double = 100.0,
    val count: Int = 1
)

@Entity(tableName = "player_state")
data class PlayerStateEntity(
    @PrimaryKey val id: Int = 1,
    val level: Int = 5,
    val exp: Int = 340,
    val maxExp: Int = 500,
    val coins: Double = 12850.0,
    val totalEarnedCoins: Double = 48500.0,
    val dailyStreak: Int = 3,
    val lastClaimTimestamp: Long = 0L,
    val userName: String = "PawsomeTrainer",
    val userId: String = "#DW-88219",
    val avatarDrawable: String = "img_dog_corgi_1786462778833",
    val soundEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true
)

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val targetCount: Int,
    val currentCount: Int,
    val rewardCoins: Double,
    val isClaimed: Boolean = false,
    val isDaily: Boolean = true
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: String, // "EARN", "SPEND", "WITHDRAW", "BONUS"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val usdValue: Double,
    val method: String, // "PayPal", "Bank Transfer", "GCash", "Crypto (USDT)"
    val accountInfo: String,
    val status: String, // "PENDING", "UNDER_REVIEW", "APPROVED", "COMPLETED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val date: String,
    val isRead: Boolean = false,
    val category: String // "NEWS", "REWARD", "SYSTEM"
)

data class LeaderboardUser(
    val rank: Int,
    val name: String,
    val level: Int,
    val scoreCoins: Double,
    val avatarRes: String,
    val isCurrentUser: Boolean = false
)
