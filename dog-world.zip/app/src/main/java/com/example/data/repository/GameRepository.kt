package com.example.data.local

import com.example.data.local.DogEntity
import com.example.data.local.DogRarity
import com.example.data.local.GameDao
import com.example.data.local.MissionEntity
import com.example.data.local.PlayerStateEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.WithdrawalEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import kotlin.random.Random

class GameRepository(private val dao: GameDao) {

    val playerState: Flow<PlayerStateEntity?> = dao.getPlayerState()
    val allDogs: Flow<List<DogEntity>> = dao.getAllDogs()
    val unlockedDogs: Flow<List<DogEntity>> = dao.getUnlockedDogs()
    val warehouseDogs: Flow<List<DogEntity>> = dao.getWarehouseDogs()
    val activeDogs: Flow<List<DogEntity>> = dao.getActiveDogs()
    val missions: Flow<List<MissionEntity>> = dao.getAllMissions()
    val transactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val withdrawals: Flow<List<WithdrawalEntity>> = dao.getAllWithdrawals()
    val messages: Flow<List<MessageEntity>> = dao.getAllMessages()
    val unreadMessageCount: Flow<Int> = dao.getUnreadMessageCount()

    suspend fun addCoins(amount: Double, sourceTitle: String) = withContext(Dispatchers.IO) {
        val state = dao.getPlayerStateSync() ?: return@withContext
        val updatedCoins = state.coins + amount
        val updatedTotal = state.totalEarnedCoins + amount
        val updatedExp = state.exp + (amount * 0.05).toInt().coerceAtLeast(10)
        
        var newLevel = state.level
        var currentExp = updatedExp
        var maxExp = state.maxExp

        if (currentExp >= maxExp) {
            newLevel += 1
            currentExp -= maxExp
            maxExp = (maxExp * 1.25).toInt()
        }

        dao.savePlayerState(
            state.copy(
                coins = updatedCoins,
                totalEarnedCoins = updatedTotal,
                level = newLevel,
                exp = currentExp,
                maxExp = maxExp
            )
        )

        dao.insertTransaction(
            TransactionEntity(
                title = sourceTitle,
                amount = amount,
                type = "EARN"
            )
        )
    }

    suspend fun spendCoins(amount: Double, spendTitle: String): Boolean = withContext(Dispatchers.IO) {
        val state = dao.getPlayerStateSync() ?: return@withContext false
        if (state.coins < amount) return@withContext false

        dao.savePlayerState(state.copy(coins = state.coins - amount))
        dao.insertTransaction(
            TransactionEntity(
                title = spendTitle,
                amount = -amount,
                type = "SPEND"
            )
        )
        return@withContext true
    }

    suspend fun upgradeDog(dogId: String): Boolean = withContext(Dispatchers.IO) {
        val dog = dao.getDogById(dogId) ?: return@withContext false
        val cost = dog.upgradeCost
        
        if (spendCoins(cost, "Upgraded ${dog.name} to Lv. ${dog.level + 1}")) {
            val updatedDog = dog.copy(
                level = dog.level + 1,
                baseEarningsPerSec = dog.baseEarningsPerSec * 1.18,
                upgradeCost = cost * 1.35
            )
            dao.updateDog(updatedDog)
            return@withContext true
        }
        return@withContext false
    }

    suspend fun toggleWarehouse(dogId: String) = withContext(Dispatchers.IO) {
        val dog = dao.getDogById(dogId) ?: return@withContext
        val newWarehouseState = !dog.isInWarehouse
        dao.updateDog(dog.copy(isInWarehouse = newWarehouseState))
    }

    suspend fun spinRandomMerge(): DogEntity? = withContext(Dispatchers.IO) {
        val allDogsList = dao.getAllDogs().firstOrNull() ?: return@withContext null
        if (allDogsList.isEmpty()) return@withContext null
        val wonDog = allDogsList[Random.nextInt(allDogsList.size)]

        val updatedDog = wonDog.copy(
            isUnlocked = true,
            count = wonDog.count + 1,
            level = wonDog.level + 1
        )
        dao.updateDog(updatedDog)

        // Award bonus spin coins
        val spinCoins = 1500.0 * (wonDog.level.coerceAtLeast(1))
        addCoins(spinCoins, "Random Merge Spin Prize (${wonDog.name})")

        return@withContext updatedDog
    }

    suspend fun synthesizeDogs(dog1Id: String, dog2Id: String): DogEntity? = withContext(Dispatchers.IO) {
        val d1 = dao.getDogById(dog1Id) ?: return@withContext null
        val d2 = dao.getDogById(dog2Id) ?: return@withContext null

        val allDogsList = dao.getAllDogs().firstOrNull() ?: return@withContext null
        
        // Find higher rarity target
        val nextRarity = when (d1.rarity) {
            DogRarity.COMMON -> DogRarity.RARE
            DogRarity.RARE -> DogRarity.EPIC
            DogRarity.EPIC -> DogRarity.LEGENDARY
            DogRarity.LEGENDARY -> DogRarity.SPECIAL
            DogRarity.SPECIAL -> DogRarity.SPECIAL
        }

        val candidates = allDogsList.filter { it.rarity == nextRarity }
        val resultDog = (candidates.ifEmpty { allDogsList }).random().copy(
            isUnlocked = true,
            level = maxOf(d1.level, d2.level) + 3,
            count = 1
        )

        dao.updateDog(resultDog)
        addCoins(5000.0, "Synthesis Masterpiece Unlocked (${resultDog.name})")
        return@withContext resultDog
    }

    suspend fun claimMission(missionId: String) = withContext(Dispatchers.IO) {
        val missionsList = dao.getAllMissions().firstOrNull() ?: return@withContext
        val mission = missionsList.find { it.id == missionId } ?: return@withContext
        if (mission.isClaimed || mission.currentCount < mission.targetCount) return@withContext

        dao.updateMission(mission.copy(isClaimed = true))
        addCoins(mission.rewardCoins, "Completed Mission: ${mission.title}")
    }

    suspend fun claimDailyReward(): Double = withContext(Dispatchers.IO) {
        val state = dao.getPlayerStateSync() ?: return@withContext 0.0
        val reward = 2500.0 * state.dailyStreak
        
        val newStreak = if (state.dailyStreak >= 7) 1 else state.dailyStreak + 1
        
        dao.savePlayerState(
            state.copy(
                dailyStreak = newStreak,
                lastClaimTimestamp = System.currentTimeMillis()
            )
        )
        addCoins(reward, "Day ${state.dailyStreak} Daily Login Streak Bonus")
        return@withContext reward
    }

    suspend fun submitWithdrawal(amountCoins: Double, method: String, accountInfo: String): Boolean = withContext(Dispatchers.IO) {
        val usdVal = amountCoins / 1000.0 // 1000 coins = $1.00 USD
        if (spendCoins(amountCoins, "Withdrawal Request ($method)")) {
            dao.insertWithdrawal(
                WithdrawalEntity(
                    amount = amountCoins,
                    usdValue = usdVal,
                    method = method,
                    accountInfo = accountInfo,
                    status = "PENDING",
                    timestamp = System.currentTimeMillis()
                )
            )
            return@withContext true
        }
        return@withContext false
    }

    suspend fun markMessageRead(messageId: String) = withContext(Dispatchers.IO) {
        dao.markMessageRead(messageId)
    }

    suspend fun markAllMessagesRead() = withContext(Dispatchers.IO) {
        dao.markAllMessagesRead()
    }

    suspend fun watchRewardedAd(): Double = withContext(Dispatchers.IO) {
        val bonusCoins = 1200.0
        addCoins(bonusCoins, "Watched Rewarded Video Ad")
        return@withContext bonusCoins
    }
}
