package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = DogGreenPrimary,
    onPrimary = Color.White,
    secondary = DogGreenSecondary,
    onSecondary = Color.White,
    tertiary = DogAmberGold,
    background = DogGreenBg,
    surface = Color.White,
    onBackground = DogDarkText,
    onSurface = DogDarkText
)

private val DarkColorScheme = darkColorScheme(
    primary = DogGreenSecondary,
    onPrimary = Color.Black,
    secondary = DogGreenLight,
    onSecondary = Color.Black,
    tertiary = DogGoldLight,
    background = Color(0xFF1B5E20),
    surface = Color(0xFF2E7D32),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
