package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.PlayerStateEntity
import com.example.ui.components.LevelBadge
import java.text.DecimalFormat

@Composable
fun ProfileScreen(
    playerState: PlayerStateEntity?,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    val state = playerState ?: PlayerStateEntity()

    val avatarResId = context.resources.getIdentifier(state.avatarDrawable, "drawable", context.packageName)
    val avatarPainter = if (avatarResId != 0) painterResource(id = avatarResId) else painterResource(id = R.drawable.ic_launcher_foreground)

    var soundEnabled by remember { mutableStateOf(state.soundEnabled) }
    var notifsEnabled by remember { mutableStateOf(state.notificationsEnabled) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F8E9)),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header Bar
        item {
            Surface(
                color = Color(0xFF2E7D32),
                shadowElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "👤 PLAYER PROFILE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        }

        // Profile Main Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = avatarPainter,
                        contentDescription = "Avatar",
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color(0xFF4CAF50), CircleShape),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = state.userName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1B5E20)
                    )

                    Text(
                        text = "Player ID: ${state.userId}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LevelBadge(level = state.level)

                    Spacer(modifier = Modifier.height(12.dp))

                    // EXP Bar
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("EXP Progress", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("${state.exp} / ${state.maxExp}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        LinearProgressIndicator(
                            progress = { (state.exp.toFloat() / state.maxExp.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = Color(0xFF4CAF50),
                            trackColor = Color(0xFFE8F5E9)
                        )
                    }
                }
            }
        }

        // Referral & Invite Section
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("INVITE FRIENDS & EARN", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color(0xFF1B5E20))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Share your referral code with friends to get +5,000 Coins for every successful join!", fontSize = 12.sp, color = Color.DarkGray)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFE8F5E9),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "DOGWORLD-9482",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }

                        Button(
                            onClick = { onShowToast("Referral code copied to clipboard!") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("SHARE CODE")
                        }
                    }
                }
            }
        }

        // Achievements Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("🏅 ACHIEVEMENTS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                Spacer(modifier = Modifier.height(8.dp))

                AchievementTile("First Merge Spin", "Spin the Random Merge Wheel", true)
                AchievementTile("Canine Collector", "Unlock 5 unique dog breeds", true)
                AchievementTile("Dog Tycoon", "Earn 50,000 lifetime coins", true)
                AchievementTile("Mythic Master", "Synthesize a Special Rarity Dog", false)
            }
        }

        // Settings Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("⚙️ GAME SETTINGS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Sound Effects & Audio BGM", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Push Notifications", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Switch(checked = notifsEnabled, onCheckedChange = { notifsEnabled = it })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AchievementTile(title: String, desc: String, isUnlocked: Boolean) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                contentDescription = null,
                tint = if (isUnlocked) Color(0xFFFF8F00) else Color.LightGray,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (isUnlocked) Color(0xFF1B5E20) else Color.Gray)
                Text(text = desc, fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}
