package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DogEntity
import com.example.data.local.DogRarity
import com.example.ui.components.DogCard

@Composable
fun DogCollectionScreen(
    allDogs: List<DogEntity>,
    warehouseDogs: List<DogEntity>,
    activeDogs: List<DogEntity>,
    onSelectDogDetails: (DogEntity) -> Unit,
    onUpgradeDog: (String) -> Unit,
    onToggleWarehouse: (String) -> Unit
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Active Roster, 1 = Warehouse
    var selectedRarityFilter by remember { mutableStateOf<DogRarity?>(null) }

    val currentList = if (selectedSection == 0) activeDogs else warehouseDogs
    val filteredDogs = currentList.filter { dog ->
        selectedRarityFilter == null || dog.rarity == selectedRarityFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F8E9))
            .padding(bottom = 80.dp)
    ) {
        // Top Header
        Surface(
            color = Color(0xFF2E7D32),
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = "🐶 DOG COLLECTION & WAREHOUSE",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Section Tab Switcher
                Box(modifier = Modifier.clip(RoundedCornerShape(12.dp))) {
                    TabRow(
                        selectedTabIndex = selectedSection,
                        containerColor = Color(0xFF1B5E20),
                        contentColor = Color.White
                    ) {
                        Tab(
                            selected = selectedSection == 0,
                            onClick = { selectedSection = 0 },
                            text = { Text("Active Yard (${activeDogs.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                            icon = { Icon(imageVector = Icons.Default.Pets, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        )
                        Tab(
                            selected = selectedSection == 1,
                            onClick = { selectedSection = 1 },
                            text = { Text("Warehouse (${warehouseDogs.size}/10)", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                            icon = { Icon(imageVector = Icons.Default.Store, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        )
                    }
                }
            }
        }

        // Rarity Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedRarityFilter == null,
                onClick = { selectedRarityFilter = null },
                label = { Text("All", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
            DogRarity.entries.forEach { rarity ->
                FilterChip(
                    selected = selectedRarityFilter == rarity,
                    onClick = { selectedRarityFilter = rarity },
                    label = { Text(rarity.name, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        if (filteredDogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (selectedSection == 0) Icons.Default.Pets else Icons.Default.Store,
                        contentDescription = null,
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (selectedSection == 0) "No active dogs in yard yet!" else "Warehouse is empty!",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = "Use Random Merge Spin to collect rare dogs!",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredDogs, key = { it.id }) { dog ->
                    DogCard(
                        dog = dog,
                        onClick = { onSelectDogDetails(dog) },
                        onActionClick = {
                            if (selectedSection == 0) {
                                onToggleWarehouse(dog.id)
                            } else {
                                onToggleWarehouse(dog.id)
                            }
                        },
                        actionLabel = if (selectedSection == 0) "STORE" else "TAKE OUT"
                    )
                }
            }
        }
    }
}
