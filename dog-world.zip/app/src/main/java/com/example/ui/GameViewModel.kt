package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DogEntity
import com.example.data.local.DogRarity
import com.example.data.local.GameRepository
import com.example.data.local.LeaderboardUser
import com.example.data.local.MessageEntity
import com.example.data.local.MissionEntity
import com.example.data.local.PlayerStateEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.WithdrawalEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class GameTab {
    HOME,
    DOGS,
    MERGE,
    WALLET,
    PROFILE
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository

    init {
        val dao = AppDatabase.getInstance(application).gameDao()
        repository = GameRepository(dao)
    }

    val playerState: StateFlow<PlayerStateEntity?> = repository.playerState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allDogs: StateFlow<List<DogEntity>> = repository.allDogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unlockedDogs: StateFlow<List<DogEntity>> = repository.unlockedDogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val warehouseDogs: StateFlow<List<DogEntity>> = repository.warehouseDogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDogs: StateFlow<List<DogEntity>> = repository.activeDogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val missions: StateFlow<List<MissionEntity>> = repository.missions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val withdrawals: StateFlow<List<WithdrawalEntity>> = repository.withdrawals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<MessageEntity>> = repository.messages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadMessageCount: StateFlow<Int> = repository.unreadMessageCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Leaderboard state
    private val _leaderboard = MutableStateFlow<List<LeaderboardUser>>(emptyList())
    val leaderboard: StateFlow<List<LeaderboardUser>> = _leaderboard.asStateFlow()

    // Navigation & UI States
    private val _activeTab = MutableStateFlow(GameTab.HOME)
    val activeTab: StateFlow<GameTab> = _activeTab.asStateFlow()

    private val _selectedDogForDetails = MutableStateFlow<DogEntity?>(null)
    val selectedDogForDetails: StateFlow<DogEntity?> = _selectedDogForDetails.asStateFlow()

    private val _isSpinning = MutableStateFlow(false)
    val isSpinning: StateFlow<Boolean> = _isSpinning.asStateFlow()

    private val _highlightedSpinIndex = MutableStateFlow(0)
    val highlightedSpinIndex: StateFlow<Int> = _highlightedSpinIndex.asStateFlow()

    private val _wonDogDialog = MutableStateFlow<DogEntity?>(null)
    val wonDogDialog: StateFlow<DogEntity?> = _wonDogDialog.asStateFlow()

    private val _showWithdrawalDialog = MutableStateFlow(false)
    val showWithdrawalDialog: StateFlow<Boolean> = _showWithdrawalDialog.asStateFlow()

    private val _showMessageCenter = MutableStateFlow(false)
    val showMessageCenter: StateFlow<Boolean> = _showMessageCenter.asStateFlow()

    private val _synthesisDog1 = MutableStateFlow<DogEntity?>(null)
    val synthesisDog1: StateFlow<DogEntity?> = _synthesisDog1.asStateFlow()

    private val _synthesisDog2 = MutableStateFlow<DogEntity?>(null)
    val synthesisDog2: StateFlow<DogEntity?> = _synthesisDog2.asStateFlow()

    private val _synthesisResultDialog = MutableStateFlow<DogEntity?>(null)
    val synthesisResultDialog: StateFlow<DogEntity?> = _synthesisResultDialog.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _isAdWatching = MutableStateFlow(false)
    val isAdWatching: StateFlow<Boolean> = _isAdWatching.asStateFlow()

    init {
        generateLeaderboardData()
    }

    fun selectTab(tab: GameTab) {
        _activeTab.value = tab
    }

    fun selectDogDetails(dog: DogEntity?) {
        _selectedDogForDetails.value = dog
    }

    fun showMessageCenter(show: Boolean) {
        _showMessageCenter.value = show
    }

    fun showWithdrawalDialog(show: Boolean) {
        _showWithdrawalDialog.value = show
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    // Interactive Actions
    fun feedDog() {
        viewModelScope.launch {
            repository.addCoins(250.0, "Fed Hero Dog (+250 Coins)")
            showToast("Nom nom! Your dog earned +250 Coins!")
        }
    }

    fun petDog() {
        viewModelScope.launch {
            repository.addCoins(150.0, "Petted Hero Dog (+150 Coins)")
            showToast("Happy Tail Wag! +150 Coins!")
        }
    }

    fun barkAction() {
        viewModelScope.launch {
            repository.addCoins(300.0, "Mega Bark Challenge (+300 Coins)")
            showToast("WOOF! Mega Bark +300 Coins!")
        }
    }

    fun upgradeDog(dogId: String) {
        viewModelScope.launch {
            val success = repository.upgradeDog(dogId)
            if (success) {
                showToast("Dog level upgraded successfully!")
            } else {
                showToast("Insufficient Coins to upgrade!")
            }
        }
    }

    fun toggleWarehouse(dogId: String) {
        viewModelScope.launch {
            repository.toggleWarehouse(dogId)
            showToast("Dog status updated!")
        }
    }

    fun spinRandomMerge() {
        if (_isSpinning.value) return
        viewModelScope.launch {
            val state = playerState.value
            val spinCost = 500.0
            if (state == null || state.coins < spinCost) {
                showToast("Need 500 Coins to Random Merge!")
                return@launch
            }

            if (!repository.spendCoins(spinCost, "Random Merge Spin Fee")) {
                showToast("Insufficient Coins!")
                return@launch
            }

            _isSpinning.value = true
            // Animate spin around 10 slots
            val totalRounds = 3 * 10 + (0..9).random()
            for (i in 0..totalRounds) {
                _highlightedSpinIndex.value = i % 10
                delay((50 + i * 8).toLong().coerceAtMost(250L))
            }

            val won = repository.spinRandomMerge()
            _isSpinning.value = false
            _wonDogDialog.value = won
        }
    }

    fun dismissWonDogDialog() {
        _wonDogDialog.value = null
    }

    // Synthesis
    fun selectDogForSynthesis(dog: DogEntity) {
        if (_synthesisDog1.value == null) {
            _synthesisDog1.value = dog
        } else if (_synthesisDog2.value == null && dog.id != _synthesisDog1.value?.id) {
            _synthesisDog2.value = dog
        } else {
            _synthesisDog1.value = dog
            _synthesisDog2.value = null
        }
    }

    fun clearSynthesisSelection() {
        _synthesisDog1.value = null
        _synthesisDog2.value = null
    }

    fun performSynthesis() {
        val d1 = _synthesisDog1.value ?: return
        val d2 = _synthesisDog2.value ?: return
        viewModelScope.launch {
            val res = repository.synthesizeDogs(d1.id, d2.id)
            _synthesisDog1.value = null
            _synthesisDog2.value = null
            _synthesisResultDialog.value = res
        }
    }

    fun dismissSynthesisResult() {
        _synthesisResultDialog.value = null
    }

    // Missions
    fun claimMission(missionId: String) {
        viewModelScope.launch {
            repository.claimMission(missionId)
            showToast("Mission Reward Claimed!")
        }
    }

    // Daily Claim
    fun claimDailyReward() {
        viewModelScope.launch {
            val reward = repository.claimDailyReward()
            if (reward > 0) {
                showToast("Claimed Day Streak Reward: +${reward.toInt()} Coins!")
            } else {
                showToast("Already claimed today's streak reward!")
            }
        }
    }

    // Withdrawal
    fun submitWithdrawal(amount: Double, method: String, account: String) {
        viewModelScope.launch {
            if (amount < 1000) {
                showToast("Minimum withdrawal is 1,000 Coins ($1.00)")
                return@launch
            }
            val success = repository.submitWithdrawal(amount, method, account)
            if (success) {
                _showWithdrawalDialog.value = false
                showToast("Withdrawal Request Submitted!")
            } else {
                showToast("Insufficient Coins for Withdrawal!")
            }
        }
    }

    // Messages
    fun markMessageRead(id: String) {
        viewModelScope.launch {
            repository.markMessageRead(id)
        }
    }

    fun markAllMessagesRead() {
        viewModelScope.launch {
            repository.markAllMessagesRead()
            showToast("All notifications marked as read.")
        }
    }

    // Watch Ad Placeholder
    fun watchRewardedAd() {
        if (_isAdWatching.value) return
        viewModelScope.launch {
            _isAdWatching.value = true
            showToast("Simulating Rewarded Ad Video (3s)...")
            delay(3000)
            val reward = repository.watchRewardedAd()
            _isAdWatching.value = false
            showToast("Ad Complete! Received +${reward.toInt()} Coins!")
        }
    }

    private fun generateLeaderboardData() {
        val mockNames = listOf(
            "BarkLord99", "CorgiQueen", "DoggoMaster", "ShibaLover", "AlphaPaws",
            "PoodlePrince", "HuskierThanYou", "BulldogChamp", "BoneHunter", "TailWagPro",
            "WoofNinja", "CanineKing", "PuppyPower", "SpotRunner", "NobleHound"
        )
        val mockAvatars = listOf(
            "img_dog_corgi_1786462778833", "img_dog_shiba_1786462789627",
            "img_dog_poodle_1786462802708", "img_app_icon_1786462753456"
        )

        val list = mutableListOf<LeaderboardUser>()
        // Current user at rank 4
        list.add(LeaderboardUser(1, "LegendaryDoggo", 25, 250000.0, mockAvatars[0]))
        list.add(LeaderboardUser(2, "ShibaKing99", 22, 185000.0, mockAvatars[1]))
        list.add(LeaderboardUser(3, "CorgiEmpress", 20, 142000.0, mockAvatars[2]))

        for (i in 4..20) {
            val name = mockNames[(i - 4) % mockNames.size]
            val lvl = 18 - (i / 2)
            val score = (120000 - i * 4500).toDouble()
            list.add(LeaderboardUser(i, name, lvl, score, mockAvatars[i % mockAvatars.size]))
        }
        _leaderboard.value = list
    }
}
