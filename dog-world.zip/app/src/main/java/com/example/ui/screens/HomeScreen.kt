package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.DogEntity
import com.example.data.local.MissionEntity
import com.example.data.local.PlayerStateEntity
import com.example.ui.components.CoinBadge
import com.example.ui.components.LevelBadge
import java.text.DecimalFormat

@Composable
fun HomeScreen(
    playerState: PlayerStateEntity?,
    activeDogs: List<DogEntity>,
    missions: List<MissionEntity>,
    unreadCount: Int,
    onFeed: () -> Unit,
    onPet: () -> Unit,
    onBark: () -> Unit,
    onClaimMission: (String) -> Unit,
    onClaimDaily: () -> Unit,
    onWatchAd: () -> Unit,
    onOpenMessages: () -> Unit,
    onSelectDogDetails: (DogEntity) -> Unit
) {
    val context = LocalContext.current
    val state = playerState ?: PlayerStateEntity()

    val heroDog = activeDogs.firstOrNull() ?: DogEntity(
        id = "corgi_king",
        name = "Royal Corgi",
        breed = "Welsh Corgi",
        level = 12,
        rarity = com.example.data.local.DogRarity.LEGENDARY,
        baseEarningsPerSec = 15.0,
        drawableName = "img_dog_corgi_1786462778833",
        description = "Royal Corgi",
        isUnlocked = true
    )

    val heroResId = context.resources.getIdentifier(heroDog.drawableName, "drawable", context.packageName)
    val heroPainter = if (heroResId != 0) painterResource(id = heroResId) else painterResource(id = R.drawable.ic_launcher_foreground)

    val bgResId = context.resources.getIdentifier("img_game_bg_1786462767428", "drawable", context.packageName)
    val bgPainter = if (bgResId != 0) painterResource(id = bgResId) else painterResource(id = R.drawable.ic_launcher_background)

    val infiniteTransition = rememberInfiniteTransition(label = "dogPulse")
    val heroScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heroScale"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F8E9)),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Top Player Status Bar
        item {
            Surface(
                color = Color(0xFF2E7D32),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF81C784),
                            border = androidx.compose.foundation.BorderStroke(2.dp, Color.White),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pets,
                                contentDescription = "Avatar",
                                tint = Color.White,
                                modifier = Modifier.padding(8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Text(
                                text = state.userName,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                            LevelBadge(level = state.level)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CoinBadge(coins = state.coins)

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = onOpenMessages,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFF388E3C))
                                .size(38.dp)
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge(
                                            containerColor = Color(0xFFFF5252),
                                            contentColor = Color.White
                                        ) {
                                            Text("$unreadCount")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Messages",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Hero Game World Stage Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    Image(
                        painter = bgPainter,
                        contentDescription = "Game World Background",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Overlay Gradient for contrast
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f))
                                )
                            )
                    )

                    // Hero Dog in the center
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(bottom = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xCC000000),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = "Lv. ${heroDog.level} ${heroDog.name}",
                                color = Color(0xFFFFD700),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Image(
                            painter = heroPainter,
                            contentDescription = heroDog.name,
                            modifier = Modifier
                                .size(135.dp)
                                .scale(heroScale)
                                .clip(CircleShape)
                                .border(4.dp, Color(0xFFFFD54F), CircleShape)
                                .clickable { onPet() },
                            contentScale = ContentScale.Crop
                        )
                    }

                    // Interactive Action Buttons Bar over image
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        GameActionButton(title = "Feed", icon = Icons.Default.Restaurant, color = Color(0xFF4CAF50), onClick = onFeed)
                        GameActionButton(title = "Pet", icon = Icons.Default.Favorite, color = Color(0xFFEC407A), onClick = onPet)
                        GameActionButton(title = "Bark", icon = Icons.Default.VolumeUp, color = Color(0xFFFF9800), onClick = onBark)
                        GameActionButton(title = "Watch Ad", icon = Icons.Default.OndemandVideo, color = Color(0xFF7E57C2), onClick = onWatchAd)
                    }
                }
            }
        }

        // Daily Streak Rewards Calendar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Daily Reward",
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Daily Login Streak (Day ${state.dailyStreak}/7)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF1B5E20)
                            )
                        }

                        Button(
                            onClick = onClaimDaily,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text("CLAIM", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items((1..7).toList()) { day ->
                            val isClaimedDay = day < state.dailyStreak
                            val isCurrentDay = day == state.dailyStreak
                            val rewardAmount = day * 2500

                            Box(
                                modifier = Modifier
                                    .size(width = 62.dp, height = 74.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        when {
                                            isClaimedDay -> Color(0xFFC8E6C9)
                                            isCurrentDay -> Color(0xFFFFF59D)
                                            else -> Color(0xFFF5F5F5)
                                        }
                                    )
                                    .border(
                                        width = if (isCurrentDay) 2.dp else 1.dp,
                                        color = if (isCurrentDay) Color(0xFFF57F17) else Color(0xFFE0E0E0),
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Day $day", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Icon(
                                        imageVector = if (isClaimedDay) Icons.Default.CheckCircle else Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = if (isClaimedDay) Color(0xFF2E7D32) else Color(0xFFFF8F00),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("+${rewardAmount / 1000}k", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF333333))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Rewards Today Section (Missions)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "🎯 REWARDS TODAY",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = Color(0xFF1B5E20)
                )

                Spacer(modifier = Modifier.height(8.dp))

                missions.forEach { mission ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = mission.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF2E7D32)
                                )
                                Text(
                                    text = mission.description,
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { (mission.currentCount.toFloat() / mission.targetCount.toFloat()).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth(0.8f)
                                        .height(6.dp)
                                        .clip(CircleShape),
                                    color = Color(0xFF4CAF50),
                                    trackColor = Color(0xFFE8F5E9)
                                )
                            }

                            Button(
                                onClick = { onClaimMission(mission.id) },
                                enabled = !mission.isClaimed && mission.currentCount >= mission.targetCount,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFFA000)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = if (mission.isClaimed) "CLAIMED" else "+${DecimalFormat("#,##0").format(mission.rewardCoins)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameActionButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = color,
        modifier = Modifier.clickable { onClick() },
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
