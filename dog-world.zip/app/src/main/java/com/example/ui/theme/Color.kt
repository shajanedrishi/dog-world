package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DogGreenPrimary = Color(0xFF2E7D32)
val DogGreenSecondary = Color(0xFF4CAF50)
val DogGreenLight = Color(0xFF81C784)
val DogGreenBg = Color(0xFFF1F8E9)

val DogAmberGold = Color(0xFFFFC107)
val DogGoldLight = Color(0xFFFFD54F)
val DogOrangeAccent = Color(0xFFFF9800)

val DogDarkText = Color(0xFF1B5E20)
val DogGrayText = Color(0xFF616161)
