package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.DogEntity
import com.example.ui.GameTab
import com.example.ui.GameViewModel
import com.example.ui.components.DogDetailsModal
import com.example.ui.components.WithdrawalDialog
import com.example.ui.components.WonDogDialog

@Composable
fun MainGameScreen(viewModel: GameViewModel) {
    val context = LocalContext.current

    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()
    val allDogs by viewModel.allDogs.collectAsStateWithLifecycle()
    val unlockedDogs by viewModel.unlockedDogs.collectAsStateWithLifecycle()
    val warehouseDogs by viewModel.warehouseDogs.collectAsStateWithLifecycle()
    val activeDogs by viewModel.activeDogs.collectAsStateWithLifecycle()
    val missions by viewModel.missions.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val withdrawals by viewModel.withdrawals.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadMessageCount.collectAsStateWithLifecycle()
    val leaderboard by viewModel.leaderboard.collectAsStateWithLifecycle()

    val isSpinning by viewModel.isSpinning.collectAsStateWithLifecycle()
    val highlightedIndex by viewModel.highlightedSpinIndex.collectAsStateWithLifecycle()
    val wonDogDialog by viewModel.wonDogDialog.collectAsStateWithLifecycle()
    val showWithdrawalDialog by viewModel.showWithdrawalDialog.collectAsStateWithLifecycle()
    val showMessageCenter by viewModel.showMessageCenter.collectAsStateWithLifecycle()

    val synthesisDog1 by viewModel.synthesisDog1.collectAsStateWithLifecycle()
    val synthesisDog2 by viewModel.synthesisDog2.collectAsStateWithLifecycle()
    val synthesisResultDialog by viewModel.synthesisResultDialog.collectAsStateWithLifecycle()

    val selectedDogForDetails by viewModel.selectedDogForDetails.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    // Handle Toast triggers
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    if (showMessageCenter) {
        MessageCenterScreen(
            messages = messages,
            onClose = { viewModel.showMessageCenter(false) },
            onMarkRead = { viewModel.markMessageRead(it) },
            onMarkAllRead = { viewModel.markAllMessagesRead() }
        )
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    contentColor = Color(0xFF2E7D32),
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    NavigationBarItem(
                        selected = activeTab == GameTab.HOME,
                        onClick = { viewModel.selectTab(GameTab.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFFC8E6C9)
                        )
                    )

                    NavigationBarItem(
                        selected = activeTab == GameTab.DOGS,
                        onClick = { viewModel.selectTab(GameTab.DOGS) },
                        icon = { Icon(Icons.Default.Pets, contentDescription = "Dogs") },
                        label = { Text("Dogs", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFFC8E6C9)
                        )
                    )

                    NavigationBarItem(
                        selected = activeTab == GameTab.MERGE,
                        onClick = { viewModel.selectTab(GameTab.MERGE) },
                        icon = { Icon(Icons.Default.Casino, contentDescription = "Merge") },
                        label = { Text("Merge", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFFC8E6C9)
                        )
                    )

                    NavigationBarItem(
                        selected = activeTab == GameTab.WALLET,
                        onClick = { viewModel.selectTab(GameTab.WALLET) },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Wallet") },
                        label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFFC8E6C9)
                        )
                    )

                    NavigationBarItem(
                        selected = activeTab == GameTab.PROFILE,
                        onClick = { viewModel.selectTab(GameTab.PROFILE) },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFFC8E6C9)
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (activeTab) {
                    GameTab.HOME -> HomeScreen(
                        playerState = playerState,
                        activeDogs = activeDogs,
                        missions = missions,
                        unreadCount = unreadCount,
                        onFeed = { viewModel.feedDog() },
                        onPet = { viewModel.petDog() },
                        onBark = { viewModel.barkAction() },
                        onClaimMission = { viewModel.claimMission(it) },
                        onClaimDaily = { viewModel.claimDailyReward() },
                        onWatchAd = { viewModel.watchRewardedAd() },
                        onOpenMessages = { viewModel.showMessageCenter(true) },
                        onSelectDogDetails = { viewModel.selectDogDetails(it) }
                    )

                    GameTab.DOGS -> DogCollectionScreen(
                        allDogs = allDogs,
                        warehouseDogs = warehouseDogs,
                        activeDogs = activeDogs,
                        onSelectDogDetails = { viewModel.selectDogDetails(it) },
                        onUpgradeDog = { viewModel.upgradeDog(it) },
                        onToggleWarehouse = { viewModel.toggleWarehouse(it) }
                    )

                    GameTab.MERGE -> MergeSpinScreen(
                        coins = playerState?.coins ?: 0.0,
                        allDogs = allDogs,
                        isSpinning = isSpinning,
                        highlightedIndex = highlightedIndex,
                        synthesisDog1 = synthesisDog1,
                        synthesisDog2 = synthesisDog2,
                        onSpin = { viewModel.spinRandomMerge() },
                        onSelectSynthesisDog = { viewModel.selectDogForSynthesis(it) },
                        onClearSynthesis = { viewModel.clearSynthesisSelection() },
                        onPerformSynthesis = { viewModel.performSynthesis() }
                    )

                    GameTab.WALLET -> WalletScreen(
                        coins = playerState?.coins ?: 0.0,
                        totalEarnedCoins = playerState?.totalEarnedCoins ?: 0.0,
                        transactions = transactions,
                        withdrawals = withdrawals,
                        onRequestWithdrawal = { viewModel.showWithdrawalDialog(true) }
                    )

                    GameTab.PROFILE -> ProfileScreen(
                        playerState = playerState,
                        onShowToast = { viewModel.showToast(it) }
                    )
                }
            }
        }
    }

    // Dialogs
    wonDogDialog?.let { dog ->
        WonDogDialog(
            dog = dog,
            onDismiss = { viewModel.dismissWonDogDialog() }
        )
    }

    synthesisResultDialog?.let { dog ->
        WonDogDialog(
            dog = dog,
            onDismiss = { viewModel.dismissSynthesisResult() }
        )
    }

    if (showWithdrawalDialog) {
        WithdrawalDialog(
            currentCoins = playerState?.coins ?: 0.0,
            onDismiss = { viewModel.showWithdrawalDialog(false) },
            onSubmit = { amount, method, account ->
                viewModel.submitWithdrawal(amount, method, account)
            }
        )
    }

    selectedDogForDetails?.let { dog ->
        DogDetailsModal(
            dog = dog,
            onDismiss = { viewModel.selectDogDetails(null) },
            onUpgrade = {
                viewModel.upgradeDog(dog.id)
                viewModel.selectDogDetails(null)
            },
            onToggleWarehouse = {
                viewModel.toggleWarehouse(dog.id)
                viewModel.selectDogDetails(null)
            },
            onFeed = {
                viewModel.feedDog()
                viewModel.selectDogDetails(null)
            }
        )
    }
}
