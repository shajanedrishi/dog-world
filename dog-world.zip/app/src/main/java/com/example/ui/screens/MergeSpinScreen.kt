package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.DogEntity
import com.example.ui.components.CoinBadge
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MergeSpinScreen(
    coins: Double,
    allDogs: List<DogEntity>,
    isSpinning: Boolean,
    highlightedIndex: Int,
    synthesisDog1: DogEntity?,
    synthesisDog2: DogEntity?,
    onSpin: () -> Unit,
    onSelectSynthesisDog: (DogEntity) -> Unit,
    onClearSynthesis: () -> Unit,
    onPerformSynthesis: () -> Unit
) {
    val context = LocalContext.current
    var activeMode by remember { mutableStateOf(0) } // 0 = Random Merge Wheel, 1 = Synthesis Station

    val displaySlots = remember(allDogs) {
        if (allDogs.size >= 10) allDogs.take(10)
        else (allDogs + List(10 - allDogs.size) { allDogs.firstOrNull() ?: DogEntity("fallback", "Dog", "Breed", 1, com.example.data.local.DogRarity.COMMON, 1.0, "img_app_icon_1786462753456", "Dog") }).take(10)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F8E9))
            .padding(bottom = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header Bar
        Surface(
            color = Color(0xFF2E7D32),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🔀 MERGE & SPIN",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                CoinBadge(coins = coins)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Mode Switcher Tabs
        TabRow(
            selectedTabIndex = activeMode,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp)),
            containerColor = Color(0xFFC8E6C9),
            contentColor = Color(0xFF1B5E20)
        ) {
            Tab(
                selected = activeMode == 0,
                onClick = { activeMode = 0 },
                text = { Text("Random Merge Spin", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp) },
                icon = { Icon(imageVector = Icons.Default.Casino, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = activeMode == 1,
                onClick = { activeMode = 1 },
                text = { Text("Synthesis Forge", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp) },
                icon = { Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (activeMode == 0) {
            // RANDOM MERGE SPIN WHEEL PANEL
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32)),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "RANDOM MERGE WHEEL",
                        color = Color(0xFFFFD54F),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Circular 10 Slots Board
                    Box(
                        modifier = Modifier
                            .size(280.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFF388E3C), Color(0xFF1B5E20))
                                )
                            )
                            .border(4.dp, Color(0xFFFFD54F), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // Central Start Area
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .size(130.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0xFFFFA000), Color(0xFFFF6F00))
                                    )
                                )
                                .border(3.dp, Color.White, CircleShape)
                                .clickable(enabled = !isSpinning) { onSpin() }
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "RANDOM\nMERGE",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(" 500", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 10 Outer Slot Circles arranged mathematically
                        for (i in 0 until 10) {
                            val angleRad = Math.toRadians((i * 36 - 90).toDouble())
                            val radiusPx = 108.0
                            val xOffset = (radiusPx * cos(angleRad)).dp
                            val yOffset = (radiusPx * sin(angleRad)).dp

                            val isHighlighted = isSpinning && (highlightedIndex == i)
                            val dogInSlot = displaySlots.getOrNull(i)

                            val slotResId = if (dogInSlot != null) {
                                context.resources.getIdentifier(dogInSlot.drawableName, "drawable", context.packageName)
                            } else 0
                            val slotPainter = if (slotResId != 0) painterResource(id = slotResId) else painterResource(id = R.drawable.ic_launcher_foreground)

                            Box(
                                modifier = Modifier
                                    .offset(x = xOffset, y = yOffset)
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (isHighlighted) Color(0xFFFFEB3B) else Color.White)
                                    .border(
                                        width = if (isHighlighted) 3.dp else 1.dp,
                                        color = if (isHighlighted) Color(0xFFFF6F00) else Color(0xFFC8E6C9),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = slotPainter,
                                    contentDescription = dogInSlot?.name,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = onSpin,
                        enabled = !isSpinning && coins >= 500,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(
                            text = if (isSpinning) "SPINNING..." else "START MERGE SPIN (500 COINS)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
            }
        } else {
            // SYNTHESIS FORGE PANEL
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "SYNTHESIS FORGE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1B5E20)
                    )
                    Text(
                        text = "Combine 2 dogs to unlock a higher rarity companion!",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SynthesisSlot(dog = synthesisDog1, label = "Dog #1")
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(28.dp))
                        SynthesisSlot(dog = synthesisDog2, label = "Dog #2")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = onPerformSynthesis,
                            enabled = synthesisDog1 != null && synthesisDog2 != null,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("SYNTHESIZE FORGE!", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onClearSynthesis,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("RESET")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Tap a dog below to place into Synthesis Slots:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Eligible Dogs Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(allDogs.filter { it.isUnlocked }) { dog ->
                            val dogResId = context.resources.getIdentifier(dog.drawableName, "drawable", context.packageName)
                            val dogPainter = if (dogResId != 0) painterResource(id = dogResId) else painterResource(id = R.drawable.ic_launcher_foreground)

                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, Color(0xFF81C784), CircleShape)
                                    .clickable { onSelectSynthesisDog(dog) },
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = dogPainter,
                                    contentDescription = dog.name,
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SynthesisSlot(dog: DogEntity?, label: String) {
    val context = LocalContext.current
    val resId = if (dog != null) context.resources.getIdentifier(dog.drawableName, "drawable", context.packageName) else 0
    val painter = if (resId != 0) painterResource(id = resId) else null

    Box(
        modifier = Modifier
            .size(90.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFFE8F5E9))
            .border(2.dp, Color(0xFF81C784), RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (dog != null && painter != null) {
            Image(
                painter = painter,
                contentDescription = dog.name,
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Text(label, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        }
    }
}
