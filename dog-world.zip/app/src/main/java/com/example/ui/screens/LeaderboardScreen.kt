package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.LeaderboardUser
import com.example.ui.components.LevelBadge
import java.text.DecimalFormat

@Composable
fun LeaderboardScreen(
    leaderboardList: List<LeaderboardUser>
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0 = Daily, 1 = Weekly, 2 = All-Time

    val top3 = leaderboardList.take(3)
    val remainingRanks = leaderboardList.drop(3)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F8E9))
            .padding(bottom = 80.dp)
    ) {
        // Header
        Surface(
            color = Color(0xFF2E7D32),
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = "🏆 DOG WORLD LEADERBOARD",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(12.dp))

                Box(modifier = Modifier.clip(RoundedCornerShape(12.dp))) {
                    TabRow(
                        selectedTabIndex = activeTab,
                        containerColor = Color(0xFF1B5E20),
                        contentColor = Color.White
                    ) {
                        Tab(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            text = { Text("Daily", fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            text = { Text("Weekly", fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            text = { Text("All-Time", fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top 3 Podium
            item {
                if (top3.size >= 3) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        PodiumCard(user = top3[1], rank = 2, medalColor = Color(0xFFC0C0C0), modifier = Modifier.weight(1f))
                        PodiumCard(user = top3[0], rank = 1, medalColor = Color(0xFFFFD700), modifier = Modifier.weight(1.1f))
                        PodiumCard(user = top3[2], rank = 3, medalColor = Color(0xFFCD7F32), modifier = Modifier.weight(1f))
                    }
                }
            }

            // Ranks 4 to 20
            items(remainingRanks) { user ->
                val avatarResId = context.resources.getIdentifier(user.avatarRes, "drawable", context.packageName)
                val avatarPainter = if (avatarResId != 0) painterResource(id = avatarResId) else painterResource(id = R.drawable.ic_launcher_foreground)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (user.isCurrentUser) Color(0xFFE8F5E9) else Color.White
                    ),
                    border = if (user.isCurrentUser) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF4CAF50)) else null,
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "#${user.rank}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.width(36.dp)
                            )

                            Image(
                                painter = avatarPainter,
                                contentDescription = user.name,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = user.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1B5E20)
                                )
                                LevelBadge(level = user.level)
                            }
                        }

                        Text(
                            text = "${DecimalFormat("#,##0").format(user.scoreCoins)} pts",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFF8F00),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PodiumCard(user: LeaderboardUser, rank: Int, medalColor: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val avatarResId = context.resources.getIdentifier(user.avatarRes, "drawable", context.packageName)
    val avatarPainter = if (avatarResId != 0) painterResource(id = avatarResId) else painterResource(id = R.drawable.ic_launcher_foreground)

    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopCenter) {
            Image(
                painter = avatarPainter,
                contentDescription = user.name,
                modifier = Modifier
                    .size(if (rank == 1) 72.dp else 58.dp)
                    .clip(CircleShape)
                    .border(3.dp, medalColor, CircleShape),
                contentScale = ContentScale.Crop
            )
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = "Medal",
                tint = medalColor,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = user.name,
            fontWeight = FontWeight.Bold,
            fontSize = if (rank == 1) 13.sp else 11.sp,
            color = Color(0xFF1B5E20),
            maxLines = 1
        )

        Text(
            text = "${DecimalFormat("#,##0").format(user.scoreCoins)}",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 11.sp,
            color = Color(0xFFFF8F00)
        )
    }
}
